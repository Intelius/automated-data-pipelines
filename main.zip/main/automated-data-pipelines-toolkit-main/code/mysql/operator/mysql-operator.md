# Key Resources and References

1. https://github.com/mysql/mysql-operator


TODO: 
1. Exposing MYSQL cluster outside the cluster 