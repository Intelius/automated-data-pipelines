export const API_URL_ROOT = window.env.API_URL_ROOT;
export const API_ONEMINUTE_PATH = "marketData/oneMinute";
export const API_NEWSDESCRIPTION_PATH = "news/description";
