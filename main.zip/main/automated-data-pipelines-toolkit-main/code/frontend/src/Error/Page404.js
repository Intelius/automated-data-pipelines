import React from "react";

const Page404 = () => {
  return (
    <div id="page404">
      <br />
      <h1>Error 404: Page Not Found</h1>
    </div>
  );
};

export default Page404;
